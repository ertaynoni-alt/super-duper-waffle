CS2 Kill Editor — landing page preview

Files:
- index.html: responsive static landing page.

To publish:
1. Create a GitHub repository and upload index.html.
2. In repository Settings → Pages, choose deploy from branch, select main / root.
3. GitHub Pages will provide a public URL after deployment.

This is a project preview only, not a functioning demo-processing service.
