CS2 Kill Editor — Supabase authentication starter

Upload index.html to the ROOT of the GitHub repository and commit it.
Netlify should publish from branch main with an empty build command and publish directory set to the repository root (or /).

Supabase setup:
1. Authentication > URL Configuration: set Site URL to https://famous-pothos-ee0313.netlify.app
2. Add https://famous-pothos-ee0313.netlify.app/** to Redirect URLs.
3. Keep email confirmation enabled if desired; users will need to confirm their email.
4. Only the publishable key is used in the browser. Never expose secret/service_role keys.

This version implements email/password sign-up, login, password reset email, and logout. It does not yet download FACEIT demos or render video highlights.
